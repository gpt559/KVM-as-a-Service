import threading
import logging
from typing import Literal, Optional
from src.serial_manager import SerialManager
from src.constants import Protocol, PROTOCOL_MAP

logger = logging.getLogger(__name__)

class ControllerService:
    """
    Business logic controller for the KVM service.
    Manages serial connection and ensures thread-safe access to hardware.
    """
    def __init__(self, serial_manager: SerialManager):
        self.serial_manager = serial_manager
        self._lock = threading.Lock()
        self.current_protocol = Protocol.CONSUMER_A
        # Initialize serial with correct baudrate
        if self.serial_manager.baudrate != 115200:
             self.serial_manager.baudrate = 115200
             if self.serial_manager.is_connected():
                 self.serial_manager.reconnect()

    def update_config(self, protocol: Optional[str] = None, baudrate: Optional[int] = None) -> None:
        """
        Updates the controller configuration.
        """
        if protocol:
            try:
                self.current_protocol = Protocol(protocol)
                logger.info(f"Protocol updated to: {self.current_protocol}")
            except ValueError:
                raise ValueError(f"Invalid protocol: {protocol}")

        if baudrate:
            if baudrate not in [9600, 38400, 115200]:
                raise ValueError(f"Invalid baudrate: {baudrate}")
            
            with self._lock:
                # Update baudrate and reconnect
                self.serial_manager.baudrate = baudrate
                if self.serial_manager.is_connected():
                    logger.info(f"Updating baudrate to {baudrate}, reconnecting...")
                    self.serial_manager.reconnect()
                else:
                    logger.info(f"Baudrate updated to {baudrate} (not currently connected)")

    def _get_commands(self):
        return PROTOCOL_MAP[self.current_protocol]

    def switch_port(self, port_id: int) -> None:
        """
        Switches the KVM to the specified port.
        
        Args:
            port_id: The target port number (1-8).
            
        Raises:
            ValueError: If port_id is invalid.
            Exception: If hardware communication fails.
        """
        if not (1 <= port_id <= 8):
            raise ValueError(f"Invalid port ID: {port_id}. Must be between 1 and 8.")

        commands = self._get_commands()
        command_name = f"SWITCH_PORT_{port_id}"
        
        if not hasattr(commands, command_name):
            raise NotImplementedError(f"Port {port_id} not supported by protocol {self.current_protocol}")

        command_bytes = getattr(commands, command_name)

        with self._lock:
            logger.info(f"Switching to port {port_id} using {self.current_protocol}")
            self.serial_manager.write(command_bytes)

    def control_buzzer(self, state: Literal["on", "off"]) -> None:
        """
        Controls the KVM buzzer.
        
        Args:
            state: "on" or "off".
        """
        commands = self._get_commands()
        
        if state == "on":
            if not hasattr(commands, 'BUZZER_ON'):
                 raise NotImplementedError(f"Buzzer control not supported by protocol {self.current_protocol}")
            command_bytes = commands.BUZZER_ON
        elif state == "off":
            if not hasattr(commands, 'BUZZER_OFF'):
                 raise NotImplementedError(f"Buzzer control not supported by protocol {self.current_protocol}")
            command_bytes = commands.BUZZER_OFF
        else:
             raise ValueError("Invalid buzzer state. Must be 'on' or 'off'.")

        with self._lock:
            logger.info(f"Turning buzzer {state} using {self.current_protocol}")
            self.serial_manager.write(command_bytes)

    def check_status(self) -> dict:
        """
        Checks the service health and connection status.
        
        Returns:
            dict: Status information.
        """
        is_connected = self.serial_manager.is_connected()
        status = "healthy" if is_connected else "degraded"
        
        # If not connected, try to connect (self-healing)
        if not is_connected:
            if self.serial_manager.connect():
                is_connected = True
                status = "healthy"
            else:
                status = "unhealthy"

        return {
            "status": status,
            "connected": is_connected,
            "port": self.serial_manager.port,
            "baudrate": self.serial_manager.baudrate,
            "protocol": self.current_protocol
        }
